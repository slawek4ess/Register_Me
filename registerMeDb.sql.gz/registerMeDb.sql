-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: registerMeDB
-- ------------------------------------------------------
-- Server version	5.7.25-0ubuntu0.18.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `EmpTemplate`
--

DROP TABLE IF EXISTS `EmpTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmpTemplate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `endTime` time NOT NULL,
  `startTime` time NOT NULL,
  `employee_id` int(11) NOT NULL,
  `endTimeObj_id` int(11) DEFAULT NULL,
  `startTimeObj_id` int(11) DEFAULT NULL,
  `weekday_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SK_constraint` (`employee_id`,`weekday_id`) COMMENT '''It have to be unique!''',
  KEY `FK4_endTimeSlot_id` (`endTimeObj_id`),
  KEY `FK3_startTimeSlot_id` (`startTimeObj_id`),
  KEY `FK2_weekday_id` (`weekday_id`),
  KEY `FK1_employee_id` (`employee_id`),
  CONSTRAINT `FK3ot4s0fqqfwjvdjikjl2x2n8l` FOREIGN KEY (`weekday_id`) REFERENCES `Weekday` (`id`),
  CONSTRAINT `FKib7byuk2l3xkr2ys0m32duxmi` FOREIGN KEY (`startTimeObj_id`) REFERENCES `TimeSlot` (`id`),
  CONSTRAINT `FKmiakyl8l8lm90a2hsjqghm6h7` FOREIGN KEY (`employee_id`) REFERENCES `Employee` (`id`),
  CONSTRAINT `FKrux1lh0bpk8jmidonfh8mn6iv` FOREIGN KEY (`endTimeObj_id`) REFERENCES `TimeSlot` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmpTemplate`
--

LOCK TABLES `EmpTemplate` WRITE;
/*!40000 ALTER TABLE `EmpTemplate` DISABLE KEYS */;
INSERT INTO `EmpTemplate` VALUES (5,'18:00:00','09:00:00',1,20,3,1),(6,'18:00:00','09:00:00',1,20,3,2),(7,'18:00:00','09:00:00',1,20,3,3),(8,'18:00:00','09:00:00',1,20,3,4),(9,'18:00:00','09:00:00',1,20,3,5),(10,'18:00:00','09:00:00',1,20,3,6),(12,'17:00:00','08:00:00',2,18,1,1),(13,'17:00:00','08:00:00',2,18,1,2),(14,'17:00:00','08:00:00',2,18,1,3),(15,'17:00:00','08:00:00',2,18,1,4),(16,'17:00:00','08:00:00',2,18,1,5),(17,'17:00:00','08:00:00',2,18,1,6);
/*!40000 ALTER TABLE `EmpTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee`
--

DROP TABLE IF EXISTS `Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee`
--

LOCK TABLES `Employee` WRITE;
/*!40000 ALTER TABLE `Employee` DISABLE KEYS */;
INSERT INTO `Employee` VALUES (1,'im@wp.pl','Irena','Malinowska','111222333'),(2,'iza@op.pl','Iza','Kowalska','555444333'),(3,'ala@wp.pl','Ala','Ma_kota','602342544'),(9,'hwoz@wp.pl','Helena','Wozniak','6676767676');
/*!40000 ALTER TABLE `Employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TimeSlot`
--

DROP TABLE IF EXISTS `TimeSlot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TimeSlot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `endTime` time NOT NULL,
  `startTime` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TimeSlot`
--

LOCK TABLES `TimeSlot` WRITE;
/*!40000 ALTER TABLE `TimeSlot` DISABLE KEYS */;
INSERT INTO `TimeSlot` VALUES (1,'08:30:00','08:00:00'),(2,'09:00:00','08:30:00'),(3,'09:30:00','09:00:00'),(4,'10:00:00','09:30:00'),(5,'10:30:00','10:00:00'),(6,'11:00:00','10:30:00'),(7,'11:30:00','11:00:00'),(8,'12:00:00','11:30:00'),(9,'12:30:00','12:00:00'),(10,'13:00:00','12:30:00'),(11,'13:30:00','13:00:00'),(12,'14:00:00','13:30:00'),(13,'14:30:00','14:00:00'),(14,'15:00:00','14:30:00'),(15,'15:30:00','15:00:00'),(16,'16:00:00','15:30:00'),(17,'16:30:00','16:00:00'),(18,'17:00:00','16:30:00'),(19,'17:30:00','17:00:00'),(20,'18:00:00','17:30:00');
/*!40000 ALTER TABLE `TimeSlot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Timetable`
--

DROP TABLE IF EXISTS `Timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Timetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `endTime` time DEFAULT NULL,
  `startTime` time DEFAULT NULL,
  `TimeObj_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `weekday_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgdauoi4h8bt87wty1xae2g86k` (`TimeObj_id`),
  KEY `FK1i1srfmu9ihln8apijeey9yjk` (`employee_id`),
  KEY `FKc9vlkuv497uugt0egpw2ye1p0` (`weekday_id`),
  CONSTRAINT `FK1i1srfmu9ihln8apijeey9yjk` FOREIGN KEY (`employee_id`) REFERENCES `Employee` (`id`),
  CONSTRAINT `FKc9vlkuv497uugt0egpw2ye1p0` FOREIGN KEY (`weekday_id`) REFERENCES `Weekday` (`id`),
  CONSTRAINT `FKgdauoi4h8bt87wty1xae2g86k` FOREIGN KEY (`TimeObj_id`) REFERENCES `TimeSlot` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Timetable`
--

LOCK TABLES `Timetable` WRITE;
/*!40000 ALTER TABLE `Timetable` DISABLE KEYS */;
/*!40000 ALTER TABLE `Timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Weekday`
--

DROP TABLE IF EXISTS `Weekday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Weekday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Weekday`
--

LOCK TABLES `Weekday` WRITE;
/*!40000 ALTER TABLE `Weekday` DISABLE KEYS */;
INSERT INTO `Weekday` VALUES (1,'Poniedzialek'),(2,'Wtorek'),(3,'Środa'),(4,'Czwartek'),(5,'Piątek'),(6,'Sobota');
/*!40000 ALTER TABLE `Weekday` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-18 19:53:55
